CREATE INDEX idx_users_to_items ON users_to_items (user_id, item_id);
